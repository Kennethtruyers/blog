
# Coder Ghost Theme for Showcasing Projects
Open sourcing the Coder Ghost theme. The coder ghost theme was built to show case my open source projects. The theme is packed with the following features :  

- mobile friendly
- beautiful syntax highlighting
- elusive icon set
- stunning typography
- thumbnail per post
- seo optimized titles
- works with Ghost Engine ^1.0


## Installation 
Goto the Github and download the repository zip archive and extract its contents. Change the contact urls in the `partials/navbar.hbs` file to your own and archive the contents. Upload the archive to your Ghost CMS. 


![](https://www.mbejda.com/content/images/2015/12/download--2-.png#400)
<hr>
If you need support send me a tweet at <br>
Twitter: [@notmilosbejda](https://twitter.com/notmilobejda)<br>
Blog: [www.mbejda.com](https://github.com/mbejda/CoderGhostTheme)<br>
Github: https://github.com/mbejda/CoderGhostTheme
